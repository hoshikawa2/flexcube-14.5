su - gsh
#cd /
#wget "https://objectstorage.us-ashburn-1.oraclecloud.com/p/Y86rX7N3n5m39BuMsxkRY-uP5O1ha2ZVEOv-oazTmA6MDf0XNtki8gGymsvYvPEf/n/id3kyspkytmr/b/bucket_banco_conceito/o/kernel144_11Mar21.zip"
#unzip -o kernel144_11Mar21.zip -d /
cd /scratch/gsh/kernel144/user_projects/domains/integrated/bin

