su - gsh
cd /
sh ExecuteWebLogic.sh
sleep 180
cd /
sh StartApps.sh
