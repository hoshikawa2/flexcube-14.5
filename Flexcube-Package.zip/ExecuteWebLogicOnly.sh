cd /
su - gsh
cd /scratch/gsh/kernel144/user_projects/domains/integrated/bin
sh /scratch/gsh/kernel144/user_projects/domains/integrated/bin/startWebLogic.sh &
